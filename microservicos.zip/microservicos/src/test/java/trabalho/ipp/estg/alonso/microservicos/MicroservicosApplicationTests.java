package trabalho.ipp.estg.alonso.microservicos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicosApplicationTests {

	@Test
	void contextLoads() {
	}

}
